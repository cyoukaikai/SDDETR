import torch
from torch import nn as nn
import torch.nn.functional as F

from models.sgdt.nms import ProposalProcess
from models.sgdt.scoring_gt import ProposalScoringParser, TokenScoringGTGenerator
from models.sgdt.scoring_loss import TokenScoringLoss
from models.sgdt.sgdt_components import extract_thd
from models.sgdt.sgdt_module import SGDT_module

SIGMA = 0.05


class GTRatioOrSigma:
    def __init__(self, gt_decay_criterion,  # default=None
                 data_size, total_epoch, decay_sigma=False
                 ):
        # for gt proposal fusion
        self.gt_decay_criterion = gt_decay_criterion
        self.data_size = data_size
        self.total_epoch = total_epoch
        self.decay_start_epoch = None
        self.decay_end_epoch = None
        self.total_steps = None
        self.gt_ratio_updater_ready = False
        self.gt_ratio = 1.0

        if self.gt_decay_criterion is not None:
            self.decay_start_epoch = 0
            self.decay_end_epoch = total_epoch

            if gt_decay_criterion != '':
                decay_start_epoch = extract_thd(gt_decay_criterion, 'start_epoch')
                if decay_start_epoch is not None:
                    assert isinstance(decay_start_epoch, (int, float)) and decay_start_epoch >= 0
                    self.decay_start_epoch = decay_start_epoch

                decay_end_epoch = extract_thd(gt_decay_criterion, 'end_epoch')
                if decay_end_epoch is not None:
                    assert isinstance(decay_end_epoch, (int, float)) and decay_end_epoch > 0
                    self.decay_end_epoch = decay_end_epoch
            assert self.decay_start_epoch < self.decay_end_epoch < self.total_epoch

            self.total_steps = self.data_size * (self.decay_end_epoch - self.decay_start_epoch)
            self.gt_ratio_updater_ready = True
        print(f'self.gt_ratio_updater_ready = {self.gt_ratio_updater_ready}')

        self.sigma_max = SIGMA
        self.sigma = SIGMA
        self.decay_sigma = decay_sigma

    def update_gt_ratio(self, cur_epoch, cur_iter):
        if self.gt_decay_criterion is not None:
            if cur_epoch < self.decay_start_epoch:
                self.gt_ratio = 1.0
            elif cur_epoch >= self.decay_end_epoch:
                self.gt_ratio = 0
            else:
                cur_step = (cur_epoch - self.decay_start_epoch) * self.data_size + cur_iter
                self.gt_ratio = 1 - cur_step / self.total_steps

    def update_sigma(self, cur_epoch, cur_iter):
        if self.decay_sigma:
            total_steps = self.data_size * self.total_epoch
            cur_step = cur_epoch * self.data_size + cur_iter
            process = cur_step / total_steps
            sigma_multiplier = 1 - process
            self.sigma = SIGMA * sigma_multiplier

    def update(self, cur_epoch, cur_iter):
        self.update_gt_ratio(cur_epoch=cur_epoch, cur_iter=cur_iter)
        self.update_sigma(cur_epoch=cur_epoch, cur_iter=cur_iter)


def init_proposal_processor(proposal_scoring):
    if proposal_scoring is not None:
        proposal_scoring_parser = ProposalScoringParser(proposal_scoring_config=proposal_scoring)
        proposal_filtering_param = proposal_scoring_parser.extract_box_filtering_parameter()
        proposal_processor = ProposalProcess(**proposal_filtering_param)
    else:
        proposal_processor = ProposalProcess()

    return proposal_processor


from models.distillation.losses import FeatureLoss


def KL(input, target):
    """https://pytorch.org/docs/stable/generated/torch.nn.KLDivLoss.html#torch.nn.KLDivLoss
    F.softmax(attn_weights, dim=-1)  in self-attention, so dim should be -1
    Args:
        input:
        target:

    Returns:

    """
    input = input.float()  # torch.Size([2, 8, 888, 888])
    target = target.float()  # torch.Size([2, 8, 888, 888])
    loss = F.kl_div(F.log_softmax(input, dim=-1, dtype=torch.float32),
                    F.softmax(target, dim=-1, dtype=torch.float32))
    return loss



class SGDT(nn.Module):
    # from fgd setting
    # tensor(0.0542, device='cuda:1', grad_fn=<AddBackward0>) loss in the beginning
    # temp = 0.5
    # alpha_fgd = 0.00005
    # beta_fgd = 0.000025
    # gamma_fgd = 0.00005
    # lambda_fgd = 0.0000005

    # tensor(0.7360, device='cuda:1', grad_fn=<AddBackward0>) loss in the beginning
    # temp = 0.5
    # alpha_fgd = 0.001
    # beta_fgd = 0.0005
    # gamma_fgd = 0.001
    # lambda_fgd = 0.000005

    def __init__(self, token_scoring_loss_criterion=None,
                 token_scoring_discard_split_criterion=None,
                 token_scoring_gt_criterion=None,
                 proposal_token_scoring_gt_criterion=None,
                 pad_fg_pixel=None,
                 proposal_scoring=None,
                 feature_distiller=None,
                 feature_distillation_teacher_feat_with_grad=False,
                 with_sgdt_attention_loss=False,
                 d_model=None,
                 disable_fg_scale_supervision=None,
                 token_adaption_visualization=None,
                 visualization_out_sub_dir=None,
                 gt_decay_criterion=None,  # start_epoch8-end_epoch11
                 encoder_layer_config=None,
                 ):
        super(SGDT, self).__init__()

        # ----------------
        self.token_scoring_gt_criterion = token_scoring_gt_criterion
        self.token_scoring_gt_generator = TokenScoringGTGenerator(
            token_scoring_gt_criterion=token_scoring_gt_criterion,
            pad_fg_pixel=pad_fg_pixel,
            proposal_scoring=proposal_scoring,
            proposal_token_scoring_gt_criterion=proposal_token_scoring_gt_criterion,
        )

        self.targets = None
        self.sgdt_target_raw = None
        self.sgdt_targets = None
        self.feat_map_size = None

        # self.sgdt_loss_weight = sgdt_loss_weight
        # assert isinstance(self.sgdt_loss_weight, (int, float))
        self.disable_fg_scale_supervision = disable_fg_scale_supervision
        self.token_scoring_loss = None
        if token_scoring_loss_criterion is not None and token_scoring_loss_criterion:
            self.token_scoring_loss = TokenScoringLoss(
                token_scoring_loss_criterion=token_scoring_loss_criterion
            )
        self.token_adaption_visualization = token_adaption_visualization
        self.visualization_out_sub_dir = visualization_out_sub_dir

        self.feature_distiller_loss = None
        self.feature_distiller = feature_distiller
        self.feature_distillation_teacher_feat_with_grad = feature_distillation_teacher_feat_with_grad
        # self.teacher_encoder_output_list = None  # for loss calculation
        if feature_distiller is not None and feature_distiller:
            temp = 0.5
            alpha_fgd = 0.0016
            beta_fgd = 0.0008
            gamma_fgd = 0.0008
            lambda_fgd = 0.000008
            # if feature_distiller == 'separate_trained_model':
            #     temp = 0.5
            #     alpha_fgd = 0.00005
            #     beta_fgd = 0.000025
            #     gamma_fgd = 0.00005
            #     lambda_fgd = 0.0000005
            # else:
            #     # tensor(0.7360, device='cuda:1', grad_fn=<AddBackward0>) loss in the beginning
            #     temp = 0.5
            #     alpha_fgd = 0.001
            #     beta_fgd = 0.0005
            #     gamma_fgd = 0.001
            #     lambda_fgd = 0.000005

            self.feature_distiller_loss = FeatureLoss(
                student_channels=256,  # TODO: adapt this later
                teacher_channels=256,  # TODO: adapt this later
                name='feature_loss',
                temp=temp,
                alpha_fgd=alpha_fgd,
                beta_fgd=beta_fgd,
                gamma_fgd=gamma_fgd,
                lambda_fgd=lambda_fgd,
            )

        self.with_sgdt_attention_loss = with_sgdt_attention_loss
        self.sgdt_attention_loss = KL

        # proposal_processor is always set.
        self.proposal_processor = init_proposal_processor(proposal_scoring)

        # the parameters of SGDT.
        self.sgdt_module = None
        if token_scoring_discard_split_criterion is not None and token_scoring_discard_split_criterion != '':
            self.sgdt_module = SGDT_module(
                embed_dim=d_model,
                token_scoring_discard_split_criterion=token_scoring_discard_split_criterion,
            )

        # for gt proposal fusion
        self.gt_decay_criterion = gt_decay_criterion
        # self.data_size = None
        # self.total_epoch = None
        # self.decay_start_epoch = None
        # self.decay_end_epoch = None
        # self.total_steps = None
        # self.gt_ratio_updater_ready = False
        # self.gt_ratio = 1.0
        self.gt_ratio_or_sigma = None
        self.encoder_layer_config = encoder_layer_config
        self.src_key_padding_mask = None

        # self.src_key_padding_mask = src_key_padding_mask  # B, H, W; to change to B, N use .flatten(1)

    def set_sgdt_targets(self, targets, feat_map_size):
        # feat_map_size =(h, w)
        self.sgdt_target_raw = self.token_scoring_gt_generator.get_gt_raw(targets=targets)
        self.sgdt_targets = self.token_scoring_gt_generator.resize_sig_value_gt(
            self.sgdt_target_raw, feat_map_size)
        self.feat_map_size = feat_map_size
        self.targets = targets
        # TODO: check if we need clone and detatch

    def update_proposal_gt(self, selected_proposals):
        assert self.sgdt_target_raw is not None, 'self.sgdt_target_raw should have been generated already.'

        self.targets, self.sgdt_target_raw = self.token_scoring_gt_generator.update_proposal_gt_raw(
            targets=self.targets, selected_proposals=selected_proposals,
            sgdt_target_raw=self.sgdt_target_raw)
        self.sgdt_targets = self.token_scoring_gt_generator.resize_sig_value_gt(
            self.sgdt_target_raw, self.feat_map_size)

    def get_input_img_sizes(self):
        return torch.stack([t['size'] for t in self.targets], dim=0)

    def set_gt_ratio_or_sigma(self, gt_ratio_or_sigma: GTRatioOrSigma):
        self.gt_ratio_or_sigma = gt_ratio_or_sigma

    @property
    def gt_ratio(self):
        if self.gt_ratio_or_sigma is not None and self.gt_ratio_or_sigma.gt_ratio_updater_ready:
            return self.gt_ratio_or_sigma.gt_ratio
        else:
            return None

    @property
    def sigma(self):
        if self.gt_ratio_or_sigma is not None:
            return self.gt_ratio_or_sigma.sigma
        else:
            return None

    def forward(self, x, mask):

        return self.sgdt_module(
            x=x, mask=mask,
            sgdt_targets=self.sgdt_targets,
            feat_map_size=self.feat_map_size,  # feat_map_size = (h, w)
            sigma=self.sigma,
            gt_ratio=self.gt_ratio
            # reclaim_padded_region=self.reclaim_padded_region
        )  # torch.Size([630, 2, 256]),torch.Size([2, 630])
    # -------------------------------
    # def update_sigma(self, cur_step, total_steps):
    #     process = cur_step / total_steps
    #     sigma_multiplier = 1 - process
    #     self.sigma = self.sigma_max * sigma_multiplier


def build_sgdt(args):
    sgdt = SGDT(
        token_scoring_gt_criterion=args.token_scoring_gt_criterion,
        token_scoring_discard_split_criterion=args.token_scoring_discard_split_criterion,
        proposal_token_scoring_gt_criterion=args.proposal_token_scoring_gt_criterion,
        d_model=args.hidden_dim,
        feature_distiller=args.feature_distillation,
        feature_distillation_teacher_feat_with_grad=args.feature_distillation_teacher_feat_with_grad,
        encoder_layer_config=args.encoder_layer_config,
        with_sgdt_attention_loss=args.with_sgdt_attention_loss,

        pad_fg_pixel=args.pad_fg_pixel,
        proposal_scoring=args.proposal_scoring,
        disable_fg_scale_supervision=args.disable_fg_scale_supervision,
        token_adaption_visualization=args.token_adaption_visualization,
        token_scoring_loss_criterion=args.token_scoring_loss_criterion,
        visualization_out_sub_dir=args.visualization_out_sub_dir,
        gt_decay_criterion=args.gt_decay_criterion,  # start_epoch8-end_epoch11
        # sgdt_loss_weight=args.sgdt_loss_weight,

    )

    # sgdt_module = None
    # if args.token_scoring_discard_split_criterion is not None and args.token_scoring_discard_split_criterion != '':
    #     sgdt_module = SGDT_module(
    #         embed_dim=args.hidden_dim,
    #         token_scoring_discard_split_criterion=args.token_scoring_discard_split_criterion,
    #     )
    return sgdt
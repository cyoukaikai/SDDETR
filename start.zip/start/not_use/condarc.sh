channels:
  - defaults
show_channel_urls: true
default_channels:
  - http://mirrors.blockelite.cn:15018/anaconda/pkgs/main
  - http://mirrors.blockelite.cn:15018/anaconda/pkgs/r
  - http://mirrors.blockelite.cn:15018/anaconda/pkgs/msys2
custom_channels:
  conda-forge: http://mirrors.blockelite.cn:15018/anaconda/cloud
  msys2: http://mirrors.blockelite.cn:15018/anaconda/cloud
  bioconda: http://mirrors.blockelite.cn:15018/anaconda/cloud
  menpo: http://mirrors.blockelite.cn:15018/anaconda/cloud
  pytorch: http://mirrors.blockelite.cn:15018/anaconda/cloud
  pytorch-lts: http://mirrors.blockelite.cn:15018/anaconda/cloud
  simpleitk: http://mirrors.blockelite.cn:15018/anaconda/cloud

#!/usr/bin/env bash

nvidia-smi -l 1


